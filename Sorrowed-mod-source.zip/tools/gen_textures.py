#!/usr/bin/env python3
"""Generates the placeholder textures (pure Python, no dependencies). Run from the project root."""
import random, struct, zlib, os

OUT = "src/main/resources/assets/sorrowed/textures"

def write_png(path, w, h, px):
    raw = b"".join(b"\x00" + bytes(c for p in px[y*w:(y+1)*w] for c in p) for y in range(h))
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    data = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(data)

def skin(path, head, shirt, legs, alpha, eyes=None, tear=None, seed=1):
    rnd = random.Random(seed)
    w = h = 64
    px = [(0, 0, 0, 0)] * (w * h)
    def fill(x0, y0, x1, y1, col):
        for y in range(y0, y1):
            for x in range(x0, x1):
                n = rnd.randint(-7, 7)
                px[y*w+x] = (max(0, min(255, col[0]+n)), max(0, min(255, col[1]+n)), max(0, min(255, col[2]+n)), alpha)
    fill(0, 0, 32, 16, head)      # head
    fill(16, 16, 40, 32, shirt)   # body
    fill(40, 16, 56, 32, shirt)   # right arm
    fill(32, 48, 48, 64, shirt)   # left arm
    fill(0, 16, 16, 32, legs)     # right leg
    fill(16, 48, 32, 64, legs)    # left leg
    if eyes:
        for (ex, ey) in ((9, 11), (13, 11)):
            for dx in range(2):
                for dy in range(2):
                    px[(ey+dy)*w+ex+dx] = (*eyes, min(255, alpha + 60))
    if tear:
        px[13*w+9] = (*tear, 255)
        px[14*w+9] = (*tear, 255)
    write_png(path, w, h, px)

def door(path, base, streak, seed):
    rnd = random.Random(seed)
    cols = [rnd.random() for _ in range(16)]
    px = []
    for y in range(16):
        for x in range(16):
            s = cols[x] > 0.72
            col = streak if s else base
            a = 150 if s else 100 + (x * 3 + y) % 20
            px.append((*col, a))
    write_png(path, 16, 16, px)

def tear(path):
    px = [(0, 0, 0, 0)] * 256
    for y in range(16):
        for x in range(16):
            dx, dy = x - 7.5, y - 10
            in_drop = dx*dx + dy*dy <= 20 or (y < 10 and y >= 3 and abs(dx) <= (y - 2) * 0.5)
            if in_drop:
                edge = dx*dx + dy*dy > 14 and y >= 10
                col = (96, 140, 190) if edge else (170, 212, 240)
                if x in (6, 7) and 9 <= y <= 11:
                    col = (235, 248, 255)
                px[y*16+x] = (*col, 255)
    write_png(path, 16, 16, px)

# The Echo: pale, see-through, sad eyes and one tear. The Hollow: dark and faceless.
skin(f"{OUT}/entity/echo.png", (205, 218, 230), (150, 172, 192), (112, 128, 152), 170, eyes=(40, 48, 66), tear=(150, 200, 240), seed=3)
skin(f"{OUT}/entity/hollow.png", (24, 24, 30), (18, 18, 24), (12, 12, 16), 255, seed=5)
door(f"{OUT}/block/unfinished_door.png", (236, 226, 170), (255, 250, 214), 11)
door(f"{OUT}/block/hush_door.png", (16, 24, 52), (84, 112, 186), 12)
door(f"{OUT}/block/drowned_door.png", (18, 84, 96), (120, 220, 220), 13)
door(f"{OUT}/block/hallway_door.png", (196, 184, 76), (255, 248, 160), 14)
door(f"{OUT}/block/backup_door.png", (250, 226, 236), (255, 255, 255), 15)
# The Listener: grey and sightless. The Mason: faceless, in a brown work vest.
skin(f"{OUT}/entity/listener.png", (170, 170, 176), (146, 146, 154), (116, 116, 124), 255, eyes=(24, 24, 28), seed=7)
skin(f"{OUT}/entity/mason.png", (200, 160, 130), (112, 78, 46), (70, 70, 84), 255, seed=9)
tear(f"{OUT}/item/rain_tear.png")
print("textures written")
