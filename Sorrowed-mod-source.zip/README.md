# Sorrowed (Forge 1.20.1)

It is raining the moment you join. It never stops. This was your friend's world, he is gone, and he left it open for you.

## What it does
- **Programmer Art** switches on when you join (client side, once).
- **Eternal rain** in the overworld, with two exceptions the events can cause: a sudden *silence*, and thunder.
- **Typewriter thoughts** above the hotbar: monospaced letters, blinking cursor, soft key clicks. At high Sorrow, letters glitch.
- **Book and Quill** on first join, a letter from him explaining why he wanted you here.
- **A grave** a few steps from the first player on first join.

## The psychological layer: Sorrow
Every player has a hidden **Sorrow** meter (0-100). Rain on open sky, night, the Hush, the Hallway, the Drowned Hall and nearby Hollows/Listeners raise it. Shelter, graves, the dry Unfinished, sleeping and the Mason lower it.

| Tier | Sorrow | What changes |
|---|---|---|
| 1 Uneasy | 30+ | Thoughts turn inward; footsteps behind you; the rain can stop dead |
| 2 Haunted | 55+ | Text glitches; vignette closes in; your "friend" types in chat; fake grave markers; Reflection; Listeners; thunder |
| 3 Breaking | 80+ | Heartbeat, Darkness pulses, static; fake "joined/left the game"; a gate appears behind you; ring of Hollows; an Echo right behind you |

Events roll every 10 seconds per player with a cooldown. Test with `/sorrowed sorrow <0-100>` and `/sorrowed event <name>` (op only): footsteps, silence, whisper, thunder, ghostgrave, reflection, listener, fakejoin, doorbehind, hollowcircle, echoclose, mason.

## Entities (each with its own gimmick)
- **Echo**: pale, see-through, far off in the rain. Keeps its distance while it rains. **When the rain stops, it walks straight toward you.** Never attacks; fades on arrival (+Sorrow).
- **Hollow**: faceless, spawns on open ground only while it rains. Slow, 30 HP, hits apply Slowness. **Will not attack anyone holding a lantern.**
- **Listener** (new): blind and still. **Only moves toward sound**: sprinting, jumping, swinging, using items. Stay perfectly quiet and it stands beside you and does nothing. Make noise and it hits hard and blinds you.
- **Reflection** (new): you, ten seconds ago, in your own skin, **walking the exact path you walked**. Stop moving and it catches up. Stare at it for 3 seconds or let it get close and it is gone.
- **Mason** (new): in the Unfinished. **Lays a plank bridge under his own feet** across the gaps. Standing near him lowers Sorrow. Hit him and he says "I wasn't done" and leaves a Rain Tear.

## Dimensions
- **The Unfinished** (`sorrowed:the_unfinished`) - reworked. A custom chunk generator: a 7x5-chunk hub platform, tall 16x16 **monoliths**, single **slabs**, and **very long ribbons** (10 chunks per piece, 16 wide) along X and Z at different heights, all floating in a pale void. Three material palettes: grass, scaffold planks, blueprint quartz. No rain. Falling off never kills you; you land back at the hub.
- **The Hush**: endless midnight dark forest.
- **The Drowned Hall** (new): a flooded world; his house sits on the sea floor holding a pocket of air.
- **The Hallway** (new): a sealed, carpeted maze of rooms, one per chunk, walls with random doorways, humming glowstone lights.
- **The Backup** (new): the world exactly as it was. Bright, dry, perfect, empty.

## Portals
Stone gates with a Doorway inside. Overworld gates lead to the Unfinished hub. The hub platform holds five gates (home, Hush, Drowned, Hallway, Backup). Every other dimension's gate returns you to the hub; the hub gate returns you where you came in.

## Structures
- **Stone Gate** (overworld, rare). **Half-Built House** with his notes (overworld, rarer; also a second one at the Unfinished hub with his last page, and one on the Drowned sea floor). **Grave** (overworld and Hush). **A gate that appears behind you** at Sorrow tier 3.

## Config (`config/sorrowed-common.toml`)
`friendName` (default "Alex"), `eternalRain`, `programmerArt`, `giveBook`, `echoes`, `psychologicalEvents`.

## Building
Push to GitHub, **upload the extracted files** (not the zip), and the workflow in `.github/workflows/build.yml` builds the jar. Download it from the run's **Artifacts** (`sorrowed-jar`).
Locally: JDK 17 and `gradle build` (Gradle 8.1.1). The jar lands in `build/libs/sorrowed-1.0.0.jar`.

## If the jar errors out
| Symptom | Cause / fix |
|---|---|
| `No settings.gradle found` | The repo holds the zip or a nested folder. The workflow now auto-extracts a zip and finds a nested root; still best to upload the extracted contents. `.github` is a hidden folder, make sure it uploaded. |
| `Unsupported class file major version` / toolchain errors | Not building on JDK 17. |
| `Could not find net.minecraftforge:forge:1.20.1-...` | Bump `forge_version` in `gradle.properties` to a current 47.x. |
| Game crashes with `NoSuchMethodError` / `NoSuchFieldError` | Jar not reobfuscated. `build.gradle` must have `finalizedBy 'reobfJar'` on the jar task. |
| `Mod file ... has missing/invalid metadata` | Unexpanded `${...}` in `mods.toml`, or `mod_id` in `gradle.properties` does not match `@Mod("sorrowed")`. The workflow checks both. |
| Missing textures (purple/black) or `Missing model` in the log | Typo in a model/blockstate path. The workflow validates every reference. |
| World fails to load with a registry/dimension error | Bad JSON in `data/sorrowed/`. The workflow parses all JSON before building. |
| `Duplicate registry key` / `Failed to load registry` on a world made before the mod | Back up the world; a datapack-style dimension added later loads fine, but a broken JSON blocks the whole world. |

Textures are generated placeholders (`python3 tools/gen_textures.py`); replace the PNGs freely.

## More ideas (not built yet)
- **Sorrow**: a lantern item that lowers it, a journal that records what you've seen, a dimension that only opens at tier 3.
- **Entities**: *The Typist* (hunched at a desk in the Hush, types your thoughts back), *Umbrella Man* (stands in the rain holding an umbrella, shelters you), *Reflection* (appears in puddles), *The Kept* (mobs that only stare).
- **Dimensions**: *The Drowned Hall* (a flooded copy of his house), *The Static* (the world glitching between versions), *The Backup* (the world before he left: sunny, perfect, frozen).
- **Portals**: puddle gates that open on stormy nights, sleeping in his bed, typing a sign at the right place.
- **Structures**: flooded library, a lighthouse that never lights, memorial wall of names, a server-room ruin, an unfinished tower.
