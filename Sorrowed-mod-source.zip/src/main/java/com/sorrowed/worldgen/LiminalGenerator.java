package com.sorrowed.worldgen;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * One generator, two worlds.
 *
 * "unfinished": chunk-aligned pieces floating in nothing. A big hub platform around the origin,
 * tall 16x16 monoliths, flat slabs, and very long 16-wide ribbons (10 chunks per piece) running
 * along X and Z at different heights. Everything between them is void.
 *
 * "hallway": a sealed, carpeted, yellow-walled maze of rooms. Every 16x16 chunk is a room with
 * walls on its west/north edges that may or may not have a doorway.
 */
public class LiminalGenerator extends ChunkGenerator {
    public static final Codec<LiminalGenerator> CODEC = RecordCodecBuilder.create(inst -> inst.group(
            BiomeSource.CODEC.fieldOf("biome_source").forGetter(g -> g.getBiomeSource()),
            Codec.STRING.fieldOf("mode").forGetter(g -> g.mode)
    ).apply(inst, inst.stable(LiminalGenerator::new)));

    public static final int MIN_Y = -64;
    public static final int HEIGHT = 384;
    /** Top block of the hub platform in the Unfinished; you stand at 65. */
    public static final int PLATFORM_TOP = 64;
    public static final int HALL_FLOOR = 64;
    public static final int HALL_CEIL = 73;

    private final String mode;

    public LiminalGenerator(BiomeSource source, String mode) {
        super(source);
        this.mode = mode;
    }

    private boolean hallway() {
        return "hallway".equals(mode);
    }

    @Override
    protected Codec<? extends ChunkGenerator> codec() {
        return CODEC;
    }

    @Override
    public void applyCarvers(WorldGenRegion region, long seed, RandomState random, BiomeManager biomes,
                             StructureManager structures, ChunkAccess chunk, GenerationStep.Carving step) {
    }

    @Override
    public void buildSurface(WorldGenRegion region, StructureManager structures, RandomState random, ChunkAccess chunk) {
    }

    @Override
    public void spawnOriginalMobs(WorldGenRegion region) {
    }

    @Override
    public int getGenDepth() {
        return HEIGHT;
    }

    @Override
    public int getSeaLevel() {
        return -63;
    }

    @Override
    public int getMinY() {
        return MIN_Y;
    }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Executor executor, Blender blender, RandomState random,
                                                        StructureManager structures, ChunkAccess chunk) {
        Heightmap oceanFloor = chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.OCEAN_FLOOR_WG);
        Heightmap surface = chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.WORLD_SURFACE_WG);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int minX = chunk.getPos().getMinBlockX();
        int minZ = chunk.getPos().getMinBlockZ();

        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int x = minX + lx;
                int z = minZ + lz;
                int lo;
                int hi;
                if (hallway()) {
                    lo = MIN_Y;
                    hi = HALL_CEIL;
                } else {
                    Span span = unfinishedSpan(x, z);
                    if (span == null) continue;
                    lo = span.bottom();
                    hi = span.top();
                }
                for (int y = lo; y <= hi; y++) {
                    BlockState state = stateAt(x, y, z);
                    if (state == null || state.isAir()) continue;
                    chunk.setBlockState(pos.set(x, y, z), state, false);
                    oceanFloor.update(lx, y, lz, state);
                    surface.update(lx, y, lz, state);
                }
            }
        }
        return CompletableFuture.completedFuture(chunk);
    }

    private int topAt(int x, int z) {
        if (hallway()) return HALL_CEIL;
        Span span = unfinishedSpan(x, z);
        return span == null ? MIN_Y - 1 : span.top();
    }

    @Override
    public int getBaseHeight(int x, int z, Heightmap.Types type, LevelHeightAccessor level, RandomState random) {
        return Math.max(level.getMinBuildHeight(), topAt(x, z) + 1);
    }

    @Override
    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor level, RandomState random) {
        BlockState[] states = new BlockState[level.getHeight()];
        for (int i = 0; i < states.length; i++) {
            BlockState s = stateAt(x, level.getMinBuildHeight() + i, z);
            states[i] = s == null ? Blocks.AIR.defaultBlockState() : s;
        }
        return new NoiseColumn(level.getMinBuildHeight(), states);
    }

    @Override
    public void addDebugScreenInfo(List<String> info, RandomState random, BlockPos pos) {
    }

    // ------------------------------------------------------------------ blocks

    private BlockState stateAt(int x, int y, int z) {
        return hallway() ? hallwayState(x, y, z) : unfinishedState(x, y, z);
    }

    private record Span(int bottom, int top, int palette) {}

    private static long mix(long a, long b, long c) {
        long h = a * 0x9E3779B97F4A7C15L ^ b * 0xC2B2AE3D27D4EB4FL ^ c * 0x165667B19E3779F9L;
        h ^= h >>> 32;
        h *= 0xD6E8FEB86659FD93L;
        h ^= h >>> 32;
        return h;
    }

    private static Span unfinishedSpan(int x, int z) {
        int cx = x >> 4;
        int cz = z >> 4;

        // The hub: a 7x5 chunk platform around the origin. The gates stand here.
        if (cx >= -3 && cx <= 3 && cz >= -2 && cz <= 2) {
            return new Span(PLATFORM_TOP - 8, PLATFORM_TOP, 0);
        }

        long h = mix(cx, cz, 1);
        int palette = (int) ((h >>> 40) % 3);

        // Monoliths: a whole chunk standing on end, up to y 220.
        if ((h & 15) == 0) {
            int top = 90 + (int) ((h >>> 8) & 127);
            return new Span(-40, top, palette);
        }

        // Long ribbons along X: 16 wide, 160 long, gently waving.
        long rowH = mix(cz, 77, 2);
        if ((rowH & 3) == 0) {
            long segH = mix(Math.floorDiv(cx, 10), cz, 3);
            if ((segH & 3) != 0) {
                int base = 30 + (int) ((rowH >>> 8) & 63);
                int top = base + (int) Math.round(5.0D * Math.sin(x / 37.0D + (rowH & 255)));
                return new Span(top - 3, top, (int) ((segH >>> 40) % 3));
            }
        }

        // Long ribbons along Z.
        long colH = mix(cx, 88, 4);
        if ((colH & 3) == 0) {
            long segH = mix(cx, Math.floorDiv(cz, 10), 5);
            if ((segH & 3) != 0) {
                int base = 50 + (int) ((colH >>> 8) & 63);
                int top = base + (int) Math.round(5.0D * Math.sin(z / 37.0D + (colH & 255)));
                return new Span(top - 3, top, (int) ((segH >>> 40) % 3));
            }
        }

        // Single floating slabs.
        if (((h >>> 4) & 7) == 0) {
            int top = 20 + (int) ((h >>> 12) & 127);
            return new Span(top - 4, top, palette);
        }
        return null;
    }

    private static BlockState unfinishedState(int x, int y, int z) {
        Span span = unfinishedSpan(x, z);
        if (span == null || y < span.bottom() || y > span.top()) return null;
        int depth = span.top() - y;
        switch (span.palette()) {
            case 1: // scaffold: planks over old stone brick
                return (depth < 2 ? Blocks.SPRUCE_PLANKS : Blocks.STONE_BRICKS).defaultBlockState();
            case 2: // blueprint: pale and unfinished
                if (depth < 1) return Blocks.SMOOTH_QUARTZ.defaultBlockState();
                return (depth < 3 ? Blocks.WHITE_CONCRETE : Blocks.STONE).defaultBlockState();
            default: // ordinary ground
                if (depth == 0) return Blocks.GRASS_BLOCK.defaultBlockState();
                return (depth < 4 ? Blocks.DIRT : Blocks.STONE).defaultBlockState();
        }
    }

    private static boolean hasWall(int cx, int cz, int salt) {
        return Math.floorMod(mix(cx, cz, salt), 3L) != 0L;
    }

    private static BlockState hallwayState(int x, int y, int z) {
        if (y == MIN_Y) return Blocks.BEDROCK.defaultBlockState();
        if (y < HALL_FLOOR - 1) return Blocks.STONE.defaultBlockState();
        if (y <= HALL_FLOOR) return Blocks.BROWN_TERRACOTTA.defaultBlockState();

        int lx = x & 15;
        int lz = z & 15;
        if (y == HALL_CEIL) {
            boolean light = (lx % 8 == 3 || lx % 8 == 4) && (lz % 8 == 3 || lz % 8 == 4);
            return (light ? Blocks.GLOWSTONE : Blocks.SMOOTH_SANDSTONE).defaultBlockState();
        }
        if (y > HALL_CEIL) return null;

        int cx = x >> 4;
        int cz = z >> 4;
        boolean pillar = lx < 2 && lz < 2;
        boolean wallW = lx == 0 && hasWall(cx, cz, 11) && !(lz >= 5 && lz <= 10);
        boolean wallN = lz == 0 && hasWall(cx, cz, 12) && !(lx >= 5 && lx <= 10);
        if (pillar) return Blocks.CUT_SANDSTONE.defaultBlockState();
        if (wallW || wallN) {
            return (y == HALL_FLOOR + 1 ? Blocks.SPRUCE_PLANKS : Blocks.SMOOTH_SANDSTONE).defaultBlockState();
        }
        return null;
    }
}
