package com.sorrowed.registry;

import com.sorrowed.Sorrowed;
import com.sorrowed.entity.EchoEntity;
import com.sorrowed.entity.HollowEntity;
import com.sorrowed.entity.ListenerEntity;
import com.sorrowed.entity.MasonEntity;
import com.sorrowed.entity.ReflectionEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Sorrowed.MODID);

    public static final RegistryObject<EntityType<EchoEntity>> ECHO = ENTITIES.register("echo",
            () -> EntityType.Builder.<EchoEntity>of(EchoEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).build("echo"));

    public static final RegistryObject<EntityType<HollowEntity>> HOLLOW = ENTITIES.register("hollow",
            () -> EntityType.Builder.<HollowEntity>of(HollowEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 2.1F).clientTrackingRange(8).build("hollow"));

    public static final RegistryObject<EntityType<ListenerEntity>> LISTENER = ENTITIES.register("listener",
            () -> EntityType.Builder.<ListenerEntity>of(ListenerEntity::new, MobCategory.MONSTER)
                    .sized(0.7F, 2.5F).clientTrackingRange(10).build("listener"));

    public static final RegistryObject<EntityType<ReflectionEntity>> REFLECTION = ENTITIES.register("reflection",
            () -> EntityType.Builder.<ReflectionEntity>of(ReflectionEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.8F).clientTrackingRange(10).build("reflection"));

    public static final RegistryObject<EntityType<MasonEntity>> MASON = ENTITIES.register("mason",
            () -> EntityType.Builder.<MasonEntity>of(MasonEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.95F).clientTrackingRange(10).build("mason"));
}
