package com.sorrowed.registry;

import com.sorrowed.Sorrowed;
import com.sorrowed.worldgen.GateFeature;
import com.sorrowed.worldgen.GraveFeature;
import com.sorrowed.worldgen.HouseFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModFeatures {
    public static final DeferredRegister<Feature<?>> FEATURES =
            DeferredRegister.create(ForgeRegistries.FEATURES, Sorrowed.MODID);

    public static final RegistryObject<Feature<?>> GATE = FEATURES.register("gate", GateFeature::new);
    public static final RegistryObject<Feature<?>> HOUSE = FEATURES.register("house", HouseFeature::new);
    public static final RegistryObject<Feature<?>> GRAVE = FEATURES.register("grave", GraveFeature::new);
}
