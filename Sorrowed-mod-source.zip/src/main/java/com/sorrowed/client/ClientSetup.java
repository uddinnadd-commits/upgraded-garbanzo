package com.sorrowed.client;

import com.sorrowed.Sorrowed;
import com.sorrowed.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Sorrowed.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.ECHO.get(), EchoRenderer::new);
        event.registerEntityRenderer(ModEntities.HOLLOW.get(), HollowRenderer::new);
        event.registerEntityRenderer(ModEntities.LISTENER.get(), ListenerRenderer::new);
        event.registerEntityRenderer(ModEntities.REFLECTION.get(), ReflectionRenderer::new);
        event.registerEntityRenderer(ModEntities.MASON.get(), MasonRenderer::new);
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent event) {
        // Registered first so the thoughts draw on top of the vignette.
        event.registerAboveAll("sorrow", (gui, graphics, partialTick, width, height) ->
                SorrowOverlay.render(graphics, width, height));
        event.registerAboveAll("thoughts", (gui, graphics, partialTick, width, height) ->
                ThoughtOverlay.render(graphics, width, height));
    }
}
