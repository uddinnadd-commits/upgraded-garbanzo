package com.sorrowed.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.sorrowed.Sorrowed;
import com.sorrowed.entity.ListenerEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ListenerRenderer extends HumanoidMobRenderer<ListenerEntity, HumanoidModel<ListenerEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(Sorrowed.MODID, "textures/entity/listener.png");

    public ListenerRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(ListenerEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(ListenerEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.1F, 1.3F, 1.1F);
    }
}
