package com.sorrowed.client;

import com.sorrowed.Sorrowed;
import com.sorrowed.entity.HollowEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class HollowRenderer extends HumanoidMobRenderer<HollowEntity, HumanoidModel<HollowEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(Sorrowed.MODID, "textures/entity/hollow.png");

    public HollowRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(HollowEntity entity) {
        return TEXTURE;
    }
}
