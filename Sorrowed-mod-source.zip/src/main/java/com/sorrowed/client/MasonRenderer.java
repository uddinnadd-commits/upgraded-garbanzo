package com.sorrowed.client;

import com.sorrowed.Sorrowed;
import com.sorrowed.entity.MasonEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MasonRenderer extends HumanoidMobRenderer<MasonEntity, HumanoidModel<MasonEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(Sorrowed.MODID, "textures/entity/mason.png");

    public MasonRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(MasonEntity entity) {
        return TEXTURE;
    }
}
