package com.sorrowed.client;

import com.sorrowed.Sorrowed;
import com.sorrowed.entity.EchoEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

import javax.annotation.Nullable;

public class EchoRenderer extends HumanoidMobRenderer<EchoEntity, HumanoidModel<EchoEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(Sorrowed.MODID, "textures/entity/echo.png");

    public EchoRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public ResourceLocation getTextureLocation(EchoEntity entity) {
        return TEXTURE;
    }

    @Nullable
    @Override
    protected RenderType getRenderType(EchoEntity entity, boolean visible, boolean invisibleToPlayer, boolean glowing) {
        return RenderType.entityTranslucent(TEXTURE);
    }
}
